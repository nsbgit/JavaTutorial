package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import logic.LAdminRegistration;
import logic.LAdminSignIn;
import logic.SystemDateAndTime;

import dto.AdminRegistrationInformation;
import dto.AdminSignInHistory;
import dto.SignInInfo;

/**
 * Servlet implementation class SAdmin
 */
public class SAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final int ADMIN_SIGN_UP = 1;
	private final int ADMIN_SIGN_IN = 2;
	private final int ADMIN_SIGN_OUT = 3;
	private int linkId;
	private AdminRegistrationInformation adminRegistrationInformation;
	private HttpSession session;
	private HttpSession session2;
	private AdminSignInHistory adminSignInHistory;
	private SignInInfo signInInfo;
	private int databaseUpdateChecker;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.commonMethod(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.commonMethod(request, response);
	}
	
	private void commonMethod(HttpServletRequest request, HttpServletResponse response) {
		linkId = Integer.parseInt(request.getParameter("linkId"));
		
		switch (linkId) {
		
		
			case ADMIN_SIGN_UP:
				
				adminRegistrationInformation = new AdminRegistrationInformation();
				
				adminRegistrationInformation.setFirstName(request.getParameter("firstName"));
				adminRegistrationInformation.setLastName(request.getParameter("lastName"));
				adminRegistrationInformation.setOrganisationName(request.getParameter("organisationName"));
				adminRegistrationInformation.seteMail(request.getParameter("eMail"));
				adminRegistrationInformation.setUserID(request.getParameter("userID"));
				adminRegistrationInformation.setPassword(request.getParameter("password"));
				adminRegistrationInformation.setOrganisationAddress(request.getParameter("organisationAddress"));
				adminRegistrationInformation.setAgree(request.getParameter("agree"));
				adminRegistrationInformation.setRegistrationDate(SystemDateAndTime.getDate());
				adminRegistrationInformation.setRegistrationDay(SystemDateAndTime.getDay());
				adminRegistrationInformation.setRegistrationTime(SystemDateAndTime.getTimeIn12HrsFormat());
				
				databaseUpdateChecker = new LAdminRegistration().insert(adminRegistrationInformation);
				
				session = request.getSession();
				
				if (databaseUpdateChecker != 0) {
					session.setAttribute("registrationMsg", "Hurray!!! Your information is successfully submitted");
				} else {
					session.setAttribute("registrationMsg", "Sorry!!! Submission failed");
				}
				
				try {
					response.sendRedirect("mainToAdminSection/adminSignUp.jsp");
				} catch (IOException e) {
					e.printStackTrace();
				}
				break;
				
				
				
				
			case ADMIN_SIGN_IN:
				
				adminRegistrationInformation = new AdminRegistrationInformation();
				
				adminRegistrationInformation.setUserID(request.getParameter("userID"));
				adminRegistrationInformation.setPassword(request.getParameter("password"));
				
				//signInInfo = new SignInInfo();
				signInInfo = new LAdminSignIn().getSignInInfo(adminRegistrationInformation);
				
				if (signInInfo.isFlagSignInInfo()) {
					try {
						session = request.getSession();
						String tempId = signInInfo.getId();
						session.setAttribute("accId", tempId);
						
						
						adminSignInHistory = new AdminSignInHistory();
						
						adminSignInHistory.setfId((String)session.getAttribute("accId"));
						adminSignInHistory.setSignInDate(SystemDateAndTime.getDate());
						adminSignInHistory.setSignInDay(SystemDateAndTime.getDay());
						adminSignInHistory.setSignInTime(SystemDateAndTime.getTimeIn12HrsFormat());
						adminSignInHistory.setSignOutDate("-");
						adminSignInHistory.setSignOutDay("-");
						adminSignInHistory.setSignOutTime("-");
						
						databaseUpdateChecker = new LAdminSignIn().insertSignInHistory(adminSignInHistory);
						
						if (databaseUpdateChecker != 0) {
							response.sendRedirect("adminSection/adminHomePage.jsp");
						} else {
							session = request.getSession();
							session.setAttribute("signInMsg", "Sign failed");
							try {
								response.sendRedirect("mainToAdminSection/adminSignIn.jsp");
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} else {
					session = request.getSession();
					session.setAttribute("signInMsg", "Worng user ID or password. Try again");
					try {
						response.sendRedirect("mainToAdminSection/adminSignIn.jsp");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				break;
				
				
			case ADMIN_SIGN_OUT:
				
				break;
	
				
				
			default:
				break;
		}
		
	}

	public HttpSession getSession2() {
		return session2;
	}

	public void setSession2(HttpSession session2) {
		this.session2 = session2;
	}

}
