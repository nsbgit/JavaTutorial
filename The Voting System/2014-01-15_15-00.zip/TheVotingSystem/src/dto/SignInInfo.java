package dto;

public class SignInInfo {
	private boolean flagSignInInfo;
	private String id;
	
	
	public boolean isFlagSignInInfo() {
		return flagSignInInfo;
	}
	public void setFlagSignInInfo(boolean flagSignInInfo) {
		this.flagSignInInfo = flagSignInInfo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	
	
	
}
