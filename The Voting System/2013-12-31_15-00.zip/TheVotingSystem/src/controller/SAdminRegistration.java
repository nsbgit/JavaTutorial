package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import logic.LAdminRegistration;
import logic.SystemDateAndTime;

import dto.AdminRegistrationInformation;

/**
 * Servlet implementation class SAdminRegistration
 */
public class SAdminRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final int USERSIGNUP=1;
	private final int USERSIGNOUT=2;
	private HttpSession session;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SAdminRegistration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.commonMethod(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.commonMethod(request, response);
	}
	
	private void commonMethod(HttpServletRequest request, HttpServletResponse response) {
		AdminRegistrationInformation adminRegistrationInformation = new AdminRegistrationInformation();
		
		adminRegistrationInformation.setFirstName(request.getParameter("firstName"));
		adminRegistrationInformation.setLastName(request.getParameter("lastName"));
		adminRegistrationInformation.setOrganisationName(request.getParameter("organisationName"));
		adminRegistrationInformation.seteMail(request.getParameter("eMail"));
		adminRegistrationInformation.setUserID(request.getParameter("userID"));
		adminRegistrationInformation.setPassword(request.getParameter("password"));
		adminRegistrationInformation.setOrganisationAddress(request.getParameter("organisationAddress"));
		adminRegistrationInformation.setAgree(request.getParameter("agree"));
		adminRegistrationInformation.setRegistrationDate(SystemDateAndTime.getDate());
		adminRegistrationInformation.setRegistrationDay(SystemDateAndTime.getDay());
		adminRegistrationInformation.setRegistrationTime(SystemDateAndTime.getTimeIn12HrsFormat());
		
		int databaseUpdateChecker = new LAdminRegistration().insert(adminRegistrationInformation);
		
		session = request.getSession();
		
		if (databaseUpdateChecker != 0) {
			session.setAttribute("registrationMsg", "Hurray!!! Your information is successfully submitted");
		} else {
			session.setAttribute("registrationMsg", "Sorry!!! Submission failed");
		}
		
		try {
			response.sendRedirect("mainToAdminSection/adminSignUp.jsp");
		} catch (IOException e) {
			e.printStackTrace();
		}
		int link=Integer.parseInt(request.getParameter("linkid"));
		switch (link) {
		case USERSIGNUP:
			
			break;
		case USERSIGNOUT:
					
					break;
			
		default:
			break;
		}
	}

}
