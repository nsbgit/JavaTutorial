package logic;

import java.util.ArrayList;
import java.util.Iterator;

import dto.AdminRegistrationInformation;

public class LAdminSignIn {
	private String sql;
	private ArrayList arrayList;
	private Iterator iterator;
	private String[] data;
	private boolean flagSignInInfo;
	public boolean getSignInInfo(AdminRegistrationInformation adminRegistrationInformation) {
		sql = "SELECT userID, password FROM admin_registration_information";
		arrayList = new DatabaseToArrayListConversion().convertToArrayList(sql);
		iterator = arrayList.iterator();
		while (iterator.hasNext()) {
			data = (String[]) iterator.next();
			
			if (data[0].equals(adminRegistrationInformation.getUserID()) && data[1].equals(adminRegistrationInformation.getPassword())) {
				flagSignInInfo = true;
				break;
			}
		}
		return flagSignInInfo;
		
	}

}
