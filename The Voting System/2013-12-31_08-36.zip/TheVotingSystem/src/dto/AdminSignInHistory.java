package dto;

public class AdminSignInHistory {
	private String fId;
	private String signInDate;
	private String signInTime;
	private String signOutDate;
	private String signOutTime;
	
	
	public String getfId() {
		return fId;
	}
	public void setfId(String fId) {
		this.fId = fId;
	}
	public String getSignInDate() {
		return signInDate;
	}
	public void setSignInDate(String signInDate) {
		this.signInDate = signInDate;
	}
	public String getSignInTime() {
		return signInTime;
	}
	public void setSignInTime(String signInTime) {
		this.signInTime = signInTime;
	}
	public String getSignOutDate() {
		return signOutDate;
	}
	public void setSignOutDate(String signOutDate) {
		this.signOutDate = signOutDate;
	}
	public String getSignOutTime() {
		return signOutTime;
	}
	public void setSignOutTime(String signOutTime) {
		this.signOutTime = signOutTime;
	}
}
