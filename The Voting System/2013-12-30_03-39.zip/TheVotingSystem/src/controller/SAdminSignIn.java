package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import logic.LAdminSignIn;

import dto.AdminRegistrationInformation;

/**
 * Servlet implementation class SAdminSignIn
 */
public class SAdminSignIn extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AdminRegistrationInformation adminRegistrationInformation;
	private boolean flagSignInInfo;
	private HttpSession session;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SAdminSignIn() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.commonMethod(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.commonMethod(request, response);
	}
	private void commonMethod(HttpServletRequest request, HttpServletResponse response) {
		adminRegistrationInformation = new AdminRegistrationInformation();
		
		adminRegistrationInformation.setUserID(request.getParameter("userID"));
		adminRegistrationInformation.setPassword(request.getParameter("password"));
		
		flagSignInInfo = new LAdminSignIn().getSignInInfo(adminRegistrationInformation);
		
		if (flagSignInInfo) {
			try {
				response.sendRedirect("adminSection/adminHomePage.jsp");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			session = request.getSession();
			session.setAttribute("signInMsg", "Worng user ID or password. Try again");
			try {
				response.sendRedirect("mainToAdminSection/adminSignIn.jsp");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
