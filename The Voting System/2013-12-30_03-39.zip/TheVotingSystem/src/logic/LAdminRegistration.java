package logic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import dto.AdminRegistrationInformation;

public class LAdminRegistration {
	private int databaseUpdateChecker;
	private Connection connection;
	private PreparedStatement preparedStatement;
	
	public int insert(AdminRegistrationInformation adminRegistrationInformation) {
		try {
			connection = DatabaseConnectionOpen.createConnection();
			
			String sql = "INSERT INTO admin_registration_information (firstName, lastName, organisationName, eMail, userID, password, organisationAddress, agree) VALUES (?,?,?,?,?,?,?,?)";
			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, adminRegistrationInformation.getFirstName());
			preparedStatement.setString(2, adminRegistrationInformation.getLastName());
			preparedStatement.setString(3, adminRegistrationInformation.getOrganisationName());
			preparedStatement.setString(4, adminRegistrationInformation.geteMail());
			preparedStatement.setString(5, adminRegistrationInformation.getUserID());
			preparedStatement.setString(6, adminRegistrationInformation.getPassword());
			preparedStatement.setString(7, adminRegistrationInformation.getOrganisationAddress());
			preparedStatement.setString(8, adminRegistrationInformation.getAgree());
			
			databaseUpdateChecker = preparedStatement.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return databaseUpdateChecker;
	}

}
