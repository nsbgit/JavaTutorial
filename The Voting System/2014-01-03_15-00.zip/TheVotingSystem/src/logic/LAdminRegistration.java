package logic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import dto.AdminRegistrationInformation;

public class LAdminRegistration {
	private int databaseUpdateChecker;
	private Connection connection;
	private PreparedStatement preparedStatement;
	private String sql;
	private ArrayList arrayList;
	private ArrayList arrayList2;
	
	public int insert(AdminRegistrationInformation adminRegistrationInformation) {
		try {
			connection = DatabaseConnectionOpen.createConnection();
			
			sql = "INSERT INTO admin_registration_information (firstName, lastName, organisationName, eMail, userID, password, organisationAddress, agree, registrationDate, registrationDay, registrationTime) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, adminRegistrationInformation.getFirstName());
			preparedStatement.setString(2, adminRegistrationInformation.getLastName());
			preparedStatement.setString(3, adminRegistrationInformation.getOrganisationName());
			preparedStatement.setString(4, adminRegistrationInformation.geteMail());
			preparedStatement.setString(5, adminRegistrationInformation.getUserID());
			preparedStatement.setString(6, adminRegistrationInformation.getPassword());
			preparedStatement.setString(7, adminRegistrationInformation.getOrganisationAddress());
			preparedStatement.setString(8, adminRegistrationInformation.getAgree());
			preparedStatement.setString(9, adminRegistrationInformation.getRegistrationDate());
			preparedStatement.setString(10, adminRegistrationInformation.getRegistrationDay());
			preparedStatement.setString(11, adminRegistrationInformation.getRegistrationTime());
			
			databaseUpdateChecker = preparedStatement.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return databaseUpdateChecker;
	}
	
	public ArrayList getRecordsByAccId(String sessionId) {
		
		sql = "SELECT id, firstName, lastName, organisationName, eMail, userID, password, organisationAddress, agree, registrationDate, registrationDay, registrationTime FROM admin_registration_information";
		//arrayList2 = new DatabaseToArrayListConversion().convertToArrayList(sql);
		arrayList = new DatabaseToArrayListConversion().convertToArrayListBySession(sql, sessionId);
		
		
		return arrayList;
		
	}
	
	public ArrayList updateBySessionId( String sessionId) {
		
		try {
			connection = DatabaseConnectionOpen.createConnection();
			
			sql = "UPDATE  admin_registration_information SET firstNam=?, lastName=?, organisationName, eMail, userID, password, organisationAddress, agree, registrationDate, registrationDay, registrationTime WHERE id=?";
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}

}
