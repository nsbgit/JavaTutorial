package logic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import dto.AdminRegistrationInformation;

public class LAdminRegistration {
	private int databaseUpdateChecker;
	private Connection connection;
	private PreparedStatement preparedStatement;
	private String sql;
	private ArrayList arrayList;
	private ArrayList arrayList2;
	private int intId;
	
	public int insert(AdminRegistrationInformation adminRegistrationInformation) {
		try {
			connection = DatabaseConnectionOpen.createConnection();
			
			sql = "INSERT INTO admin_registration_information (firstName, lastName, organisationName, eMail, userID, password, organisationAddress, agree, fileName, registrationDate, registrationDay, registrationTime) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, adminRegistrationInformation.getFirstName());
			preparedStatement.setString(2, adminRegistrationInformation.getLastName());
			preparedStatement.setString(3, adminRegistrationInformation.getOrganisationName());
			preparedStatement.setString(4, adminRegistrationInformation.geteMail());
			preparedStatement.setString(5, adminRegistrationInformation.getUserID());
			preparedStatement.setString(6, adminRegistrationInformation.getPassword());
			preparedStatement.setString(7, adminRegistrationInformation.getOrganisationAddress());
			preparedStatement.setString(8, adminRegistrationInformation.getAgree());
			preparedStatement.setString(9, adminRegistrationInformation.getFileName());
			preparedStatement.setString(10, adminRegistrationInformation.getRegistrationDate());
			preparedStatement.setString(11, adminRegistrationInformation.getRegistrationDay());
			preparedStatement.setString(12, adminRegistrationInformation.getRegistrationTime());
			
			databaseUpdateChecker = preparedStatement.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return databaseUpdateChecker;
	}
	
	public ArrayList getRecordsByAccId(String sessionId) {
		
		sql = "SELECT id, firstName, lastName, organisationName, eMail, userID, password, organisationAddress, agree, registrationDate, registrationDay, registrationTime FROM admin_registration_information";
		//arrayList2 = new DatabaseToArrayListConversion().convertToArrayList(sql);
		arrayList = new DatabaseToArrayListConversion().convertToArrayListBySession(sql, sessionId);
		
		
		return arrayList;
		
	}
	
	public int updateBySessionId( String sessionId, AdminRegistrationInformation adminRegistrationInformation) {
		
		try {
			connection = DatabaseConnectionOpen.createConnection();
			intId = Integer.parseInt(sessionId);
			
			
			sql = "UPDATE admin_registration_information SET firstName = ?, lastName = ?, organisationName = ?,eMail = ?, organisationAddress = ? WHERE id = ?" ;
			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, adminRegistrationInformation.getFirstName());
			preparedStatement.setString(2, adminRegistrationInformation.getLastName());
			preparedStatement.setString(3, adminRegistrationInformation.getOrganisationName());
			preparedStatement.setString(4, adminRegistrationInformation.geteMail());
			preparedStatement.setString(5, adminRegistrationInformation.getOrganisationAddress());
			preparedStatement.setString(6, sessionId);
			
			databaseUpdateChecker = preparedStatement.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return databaseUpdateChecker;
		
	}

}
