package dto;

public class VotingSchedule {
	private int idVotingSchedule;
	private int fidAdminRegistrationInformation;
	private String startDate;
	private String startTime;
	private String endDate;
	private String endTime;
	
	
	
	public int getIdVotingSchedule() {
		return idVotingSchedule;
	}
	public void setIdVotingSchedule(int idVotingSchedule) {
		this.idVotingSchedule = idVotingSchedule;
	}
	public int getFidAdminRegistrationInformation() {
		return fidAdminRegistrationInformation;
	}
	public void setFidAdminRegistrationInformation(
			int fidAdminRegistrationInformation) {
		this.fidAdminRegistrationInformation = fidAdminRegistrationInformation;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
}
