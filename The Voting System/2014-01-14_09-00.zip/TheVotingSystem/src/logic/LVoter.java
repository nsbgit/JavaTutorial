package logic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import dto.AdminRegistrationInformation;
import dto.SignInInfo;
import dto.VoterRegistrationInformation;
import dto.VoterSignInHistory;

public class LVoter {
	public static boolean checkUserIdAvailability(String userId) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		boolean flag = false;
		
		
		try {
			connection = DatabaseConnectionOpen.createConnection();
			String sql = "SELECT idVoterRegistrationInformation FROM voter_registration_information WHERE userId=?";
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, userId);
			
			resultSet = preparedStatement.executeQuery();
			//columnCount = resultSet.getMetaData().getColumnCount();
			if (resultSet.next()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return flag;
		
	}

	private String sql;
	private ArrayList arrayList;
	private Iterator iterator;
	private String[] data;
	private SignInInfo signInInfo;
	private Connection connection;
	private PreparedStatement preparedStatement;
	private int databaseUpdateChecker;
	
	public SignInInfo getSignInInfo(VoterRegistrationInformation voterRegistrationInformation) {
		sql = "SELECT idVoterRegistrationInformation, userId, password FROM voter_registration_information";
		arrayList = new DatabaseToArrayListConversion().convertToArrayList(sql);
		iterator = arrayList.iterator();
		while (iterator.hasNext()) {
			data = (String[]) iterator.next();
			
			if (data[1].equals(voterRegistrationInformation.getUserId()) && data[2].equals(voterRegistrationInformation.getPassword())) {
				signInInfo = new SignInInfo();
				signInInfo.setId(data[0]);
				signInInfo.setFlagSignInInfo(true);
				break;
			}
		}
		return signInInfo;
	}

	public int insertSignInHistory(VoterSignInHistory voterSignInHistory) {
		
		try {
			connection = null;
			connection = DatabaseConnectionOpen.createConnection();
			
			sql = null;
			sql = "INSERT INTO voter_sign_in_history (fIdVoterRegistrationInformation, signInDate, signInDay, signInTime, signOutDate, signOutDay, signOutTime) VALUES (?, ?, ?, ?, ?, ?, ?)";
			
			preparedStatement = null;
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, "" + voterSignInHistory.getfIdVoterRegistrationInformation());
			preparedStatement.setString(2, voterSignInHistory.getSignInDate());
			preparedStatement.setString(3, voterSignInHistory.getSignInDay());
			preparedStatement.setString(4, voterSignInHistory.getSignInTime());
			preparedStatement.setString(5, voterSignInHistory.getSignOutDate());
			preparedStatement.setString(6, voterSignInHistory.getSignOutDay());
			preparedStatement.setString(7, voterSignInHistory.getSignOutTime());
			
			databaseUpdateChecker = 0;
			databaseUpdateChecker = preparedStatement.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return databaseUpdateChecker;
	}
}
